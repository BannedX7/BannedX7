import os
import time
from tqdm import tqdm
import urllib.parse
from colorama import Fore, Style

def escrever_com_animacao(frase):
    for letra in frase:
        print(letra, end='', flush=True)
        time.sleep(0.05)
    print()

def buscar_e_escrever_linhas_com_palavra_chave(nome_arquivo, palavra_chave):
    linhas_relevantes = []
    erros_decodificacao = 0
    with open(nome_arquivo, 'rb') as arquivo:
        for linha_bytes in arquivo:
            try:
                linha = linha_bytes.decode('utf-8')
                if palavra_chave in linha:
                    linhas_relevantes.append(linha.strip())
            except UnicodeDecodeError:
                erros_decodificacao += 1
    return linhas_relevantes, erros_decodificacao

def limpar_nome_arquivo(nome_arquivo):
    caracteres_invalidos = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    for char in caracteres_invalidos:
        nome_arquivo = nome_arquivo.replace(char, '_')
    return nome_arquivo

def main():
    pasta_db = "db"

    print(Fore.YELLOW, end="")
    escrever_com_animacao("Digite a URL/palavra-chave que quer encontrar em suas DB's: ")
    print(Style.RESET_ALL, end="")
    palavra_chave = input()
    palavra_chave_encoded = urllib.parse.quote(palavra_chave)

    nome_arquivo_saida = f"{limpar_nome_arquivo(palavra_chave_encoded)}.txt"

    arquivos_txt = [arquivo for arquivo in os.listdir(pasta_db) if arquivo.endswith('.txt')]

    with tqdm(total=len(arquivos_txt), desc="Progresso da pesquisa") as progresso_barra:
        total_linhas_encontradas = 0
        total_erros_decodificacao = 0
        with open(nome_arquivo_saida, 'w') as arquivo_saida:
            for arquivo_txt in arquivos_txt:
                caminho_arquivo = os.path.join(pasta_db, arquivo_txt)
                linhas_relevantes, erros_decodificacao = buscar_e_escrever_linhas_com_palavra_chave(caminho_arquivo, palavra_chave)
                total_linhas_encontradas += len(linhas_relevantes)
                total_erros_decodificacao += erros_decodificacao
                if linhas_relevantes:
                    arquivo_saida.write(f"Linhas relevantes de '{arquivo_txt}':\n")
                    arquivo_saida.writelines("\n".join(linhas_relevantes))
                    arquivo_saida.write("\n\n")
                progresso_barra.update(1)
                time.sleep(0.1)

    if total_linhas_encontradas == 0:
        print(Fore.RED, end="")
        escrever_com_animacao("Nenhuma linha relevante encontrada.")
        print(Style.RESET_ALL)
    else:
        print(Fore.GREEN + f"Processo concluído. ", end="")
        escrever_com_animacao(f"{total_linhas_encontradas} linhas relevantes foram encontradas e escritas no arquivo '{nome_arquivo_saida}'.")
        print(Style.RESET_ALL)
        
    if total_erros_decodificacao > 0:
        print(f"Total de erros de decodificação: {total_erros_decodificacao}")

    print(Fore.GREEN, end="")
    escrever_com_animacao("Script feito por @bannedX7. Caso tenha alguma dúvida de como funciona, me chame no telegram. >>@bannedX7<<")
    print(Style.RESET_ALL)

if __name__ == "__main__":
    main()
